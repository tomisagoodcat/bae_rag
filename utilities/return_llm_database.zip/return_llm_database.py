from langchain_openai import ChatOpenAI
from neo4j import GraphDatabase
from llama_index.llms.openai import OpenAI
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from neo4j_graphrag.llm import OpenAILLM
from neo4j_graphrag.embeddings.sentence_transformers import SentenceTransformerEmbeddings
from sentence_transformers import SentenceTransformer
import torch
from neo4j import GraphDatabase

class DatabaseManager:
    def __init__(self, remotedatebase=False, embed_model="neo4j"):
        """初始化数据库管理器"""
        self.remotedatebase = remotedatebase
        self.embed_model_type = embed_model
        
        # 初始化组件
        self.llm = self._init_llm()
        self.embed_model = self._init_embedding()
        self.neo4j_driver = self._init_database()
    
    def _init_llm(self):
        """初始化LLM"""
        return OpenAILLM(
            model_name="deepseek-chat",
            model_params={
                "max_tokens": 8000,
                "temperature": 0.1,
                "top_p": 0.9,
                "frequency_penalty": 0.1,
            },
            api_key="sk-19ad3ff09b0d4f8a99f86cf50a33d86d",
            base_url='https://api.deepseek.com/beta'
        )
    
    def _init_embedding(self):
        """初始化嵌入模型"""
        if self.embed_model_type == "neo4j":
            return SentenceTransformerEmbeddings(model="maidalun1020/bce-embedding-base_v1")
        else:
            return HuggingFaceEmbedding(model_name="maidalun1020/bce-embedding-base_v1")
    
    def _init_database(self):
        """初始化数据库连接"""
        if self.remotedatebase:
            NEO4J_URI = "neo4j+s://1b6c92d6.databases.neo4j.io"
            NEO4J_USERNAME = "neo4j"
            NEO4J_PASSWORD = "jX0VJABlxEl-pFpjewsGnwfcieha0vAdf7UQrAXwDTs"
            return GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USERNAME, NEO4J_PASSWORD))
        else:
            config = {
                'url': "bolt://localhost:7687",
                'username': "neo4j",
                'password': "tomis1cat"
            }
            return GraphDatabase.driver(config['url'], auth=(config['username'], config['password']))
    
    def clear_database(self):
        """清空Neo4j数据库"""
        if not self.neo4j_driver:
            print("错误: 数据库驱动为空")
            return False
        
        try:
            with self.neo4j_driver.session() as session:
                session.run("MATCH (n) DETACH DELETE n")
                print("数据库已清空")
            return True
        except Exception as e:
            print(f"清空数据库失败: {e}")
            return False
    
    def get_components(self):
        """返回所有组件"""
        return self.llm, self.embed_model, self.neo4j_driver
    
    def close(self):
        """关闭数据库连接"""
        if self.neo4j_driver:
            self.neo4j_driver.close()
            print("数据库连接已关闭")

# 为了向后兼容，保留原有函数
    def return_llm_database(remotedatebase=False, embed_model="neo4j"):
        """向后兼容的函数"""
        manager = DatabaseManager(remotedatebase, embed_model)
        return manager.get_components()

    def clear_database(neo4j_driver):
        """向后兼容的清空数据库函数"""
        if not neo4j_driver:
            print("错误: 数据库驱动为空")
            return False
        
        try:
            with neo4j_driver.session() as session:
                session.run("MATCH (n) DETACH DELETE n")
                print("数据库已清空")
            return True
        except Exception as e:
            print(f"清空数据库失败: {e}")
            return False
        

    # ========= 新增：静态方法，直接返回 neo4j driver =========
    @staticmethod
    def get_neo4j_driver(remotedatebase=False):
            """
            静态初始化并返回 Neo4j 驱动。
            用法：driver = DatabaseManager.get_neo4j_driver(remotedatebase=True/False)
            """
            if remotedatebase:
                NEO4J_URI = "neo4j+s://1b6c92d6.databases.neo4j.io"
                NEO4J_USERNAME = "neo4j"
                NEO4J_PASSWORD = "jX0VJABlxEl-pFpjewsGnwfcieha0vAdf7UQrAXwDTs"
                return GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USERNAME, NEO4J_PASSWORD))
            else:
                config = {
                    'url': "bolt://localhost:7687",
                    'username': "neo4j",
                    'password': "tomis1cat"
                }
                return GraphDatabase.driver(config['url'], auth=(config['username'], config['password']))
        # ========= 新增：静态方法，直接返回 llm模型 =========
    @staticmethod
    def get_llm(type="deepseek"):
            """
            静态初始化并返回 Neo4j 驱动。
            用法：driver = DatabaseManager.get_neo4j_driver(remotedatebase=True/False)
            """


            if type=="deepseek":               
                return OpenAILLM(
                    model_name="deepseek-chat",
                    model_params={
                        "max_tokens": 8000,
                        "temperature": 0.1,
                        "top_p": 0.9,
                        "frequency_penalty": 0.1,
                    },
                    api_key="sk-19ad3ff09b0d4f8a99f86cf50a33d86d",
                    base_url='ttps://api.deepseek.com/v1'
                )
            else:
                return None
              
        # ========= 新增结束 =========
    # ========= 新增：静态方法，直接返回 embedding=========
    @staticmethod
    def get_embedding(type="neo4j"):
        """
        静态初始化并返回 embedding。
        用法：type="neo4j" 默认为neo4j 检索使用的embedding驱动方式，否则为标准huggingface embedding
        """
        if type == "neo4j":
            return SentenceTransformerEmbeddings(model="maidalun1020/bce-embedding-base_v1")
        elif type == "huggingface":
            return HuggingFaceEmbedding(model_name="maidalun1020/bce-embedding-base_v1")
        else:
            return None
        # ========= 新增结束 =========

from openai import OpenAI

# DeepSeek 客户端
deepseek_client = OpenAI(
    api_key="your-deepseek-api-key",
    base_url="https://api.deepseek.com"
)

# OpenAI 客户端（可选）
openai_client = OpenAI(
    api_key="your-openai-api-key"
)

def chat(messages, model="deepseek-chat", temperature=0, config={}):
    """
    与 DeepSeek API 兼容的 chat 函数。
    参数与 OpenAI 的版本完全一致。
    """
    import openai

    openai.api_key = "sk-19ad3ff09b0d4f8a99f86cf50a33d86d"
    openai.base_url = "https://api.deepseek.com/beta"
    response = openai.chat.completions.create(
        model=model,
        temperature=temperature,
        messages=messages,
        **config,
    )
    return response.choices[0].message.content
